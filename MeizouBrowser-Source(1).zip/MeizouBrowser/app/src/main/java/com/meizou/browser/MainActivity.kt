package com.meizou.browser

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.graphics.Color
import android.graphics.Typeface
import android.widget.*

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private val bg = Color.rgb(17, 24, 39)
    private val accent = Color.rgb(53, 214, 232)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val brand = TextView(this).apply {
            text = "Ｍ  MEIZOU BROWSER"
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16, 12, 16, 8)
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, 52))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(10, 4, 10, 8)
            gravity = Gravity.CENTER_VERTICAL
        }
        address = EditText(this).apply {
            hint = "Поиск или адрес сайта"
            textSize = 15f
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_GO
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setPadding(14, 4, 14, 4)
            setBackgroundColor(Color.rgb(39, 51, 69))
        }
        bar.addView(address, LinearLayout.LayoutParams(0, 48, 1f))
        val go = Button(this).apply {
            text = "Перейти"
            setTextColor(bg)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent))
            setOnClickListener { loadAddress() }
        }
        bar.addView(go)
        root.addView(bar)

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    address.setText(url ?: "")
                }
            }
            webChromeClient = WebChromeClient()
            loadUrl("https://www.google.com")
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(8, 4, 8, 4)
            setBackgroundColor(Color.rgb(25, 35, 50))
        }
        fun navButton(label: String, action: () -> Unit) {
            bottom.addView(Button(this).apply {
                text = label
                setTextColor(Color.WHITE)
                setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(39, 51, 69)))
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(0, 48, 1f))
        }
        navButton("Назад") { if (web.canGoBack()) web.goBack() }
        navButton("Домой") { web.loadUrl("https://www.google.com") }
        navButton("Обновить") { web.reload() }
        root.addView(bottom)
        setContentView(root)

        address.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) { loadAddress(); true } else false
        }
    }

    private fun loadAddress() {
        var value = address.text.toString().trim()
        if (value.isEmpty()) return
        val url = if (value.contains(" ") || (!value.contains(".") && !value.startsWith("http"))) {
            "https://www.google.com/search?q=" + java.net.URLEncoder.encode(value, "UTF-8")
        } else if (!value.startsWith("http://") && !value.startsWith("https://")) {
            "https://$value"
        } else value
        web.loadUrl(url)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
